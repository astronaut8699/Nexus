import tkinter as tk
from tkinter import messagebox
import threading
import time
import random

from pynput import mouse, keyboard


# ============================================================
# NEXUS AUTOMATION
# ============================================================

APP_TITLE = "NEXUS AUTOMATION"
MAX_CPS = 1000


# ============================================================
# GLOBAL STATE
# ============================================================

running = False
jitter_running = False
scheduler_running = False

current_mode = "click"

mouse_controller = mouse.Controller()
keyboard_controller = keyboard.Controller()

emergency_listener = None
hotkey_listener = None
hold_listener = None

hold_active = False

scheduler_thread = None

current_tab = None

# GUI references
content_container = None
tab_bar = None
tab_indicator = None
tab_buttons = {}

status_label = None
start_button = None

cps_entry = None
start_delay_entry = None

random_min_entry = None
random_max_entry = None

burst_clicks_entry = None
burst_pause_entry = None

hold_key_entry = None

jitter_distance_entry = None
jitter_delay_entry = None

scheduler_start_entry = None
scheduler_stop_entry = None

hotkey_entry = None

mode_buttons = {}


# ============================================================
# COLORS
# ============================================================

COLORS = {
    "bg": "#050811",
    "panel": "#0b1020",
    "panel2": "#101a2e",
    "entry": "#070c17",
    "border": "#17304a",

    "text": "#e9fbff",
    "muted": "#71839e",

    "cyan": "#00f5ff",
    "blue": "#168cff",
    "purple": "#9b4dff",
    "pink": "#ff20d6",

    "green": "#00ff9c",
    "red": "#ff3864",
    "yellow": "#ffd84d"
}


def color(name):
    return COLORS[name]


# ============================================================
# ROOT
# ============================================================

root = tk.Tk()

root.title(APP_TITLE)
root.geometry("1100x760")
root.minsize(850, 620)

root.configure(
    bg=color("bg")
)


# ============================================================
# POPUP
# ============================================================

def neon_popup(title, message, kind="info"):

    popup = tk.Toplevel(root)

    popup.title(title)
    popup.geometry("450x260")
    popup.resizable(False, False)
    popup.configure(bg=color("bg"))
    popup.transient(root)

    if kind == "error":
        accent = color("red")
        icon = "✕"

    elif kind == "warning":
        accent = color("yellow")
        icon = "!"

    elif kind == "success":
        accent = color("green")
        icon = "✓"

    else:
        accent = color("cyan")
        icon = "◆"

    outer = tk.Frame(
        popup,
        bg=color("panel"),
        highlightbackground=accent,
        highlightthickness=2
    )

    outer.pack(
        fill="both",
        expand=True,
        padx=3,
        pady=3
    )

    tk.Label(
        outer,
        text=icon,
        font=("Segoe UI", 30, "bold"),
        fg=accent,
        bg=color("panel")
    ).pack(
        pady=(18, 2)
    )

    tk.Label(
        outer,
        text=title.upper(),
        font=("Segoe UI", 13, "bold"),
        fg=accent,
        bg=color("panel")
    ).pack()

    tk.Label(
        outer,
        text=message,
        font=("Segoe UI", 10),
        fg=color("text"),
        bg=color("panel"),
        wraplength=370,
        justify="center"
    ).pack(
        pady=15,
        padx=20
    )

    tk.Button(
        outer,
        text="OK",
        command=popup.destroy,
        font=("Segoe UI", 10, "bold"),
        fg=accent,
        bg=color("panel2"),
        activebackground=accent,
        activeforeground=color("bg"),
        relief="flat",
        bd=0,
        width=14,
        cursor="hand2"
    ).pack()

    popup.bind(
        "<Return>",
        lambda event: popup.destroy()
    )

    popup.bind(
        "<Escape>",
        lambda event: popup.destroy()
    )


# ============================================================
# WIDGET HELPERS
# ============================================================

def neon_button(
    parent,
    text,
    command,
    accent=None,
    width=22
):

    accent = accent or color("cyan")

    return tk.Button(
        parent,
        text=text,
        command=command,
        font=("Segoe UI", 10, "bold"),
        fg=accent,
        bg=color("panel2"),
        activeforeground=color("bg"),
        activebackground=accent,
        relief="flat",
        bd=0,
        width=width,
        height=2,
        cursor="hand2"
    )


def make_entry(parent, default="", width=20):

    entry = tk.Entry(
        parent,
        font=("Segoe UI", 11),
        fg=color("text"),
        bg=color("entry"),
        insertbackground=color("cyan"),
        selectbackground=color("purple"),
        relief="flat",
        bd=0,
        width=width
    )

    entry.insert(
        0,
        default
    )

    return entry


def make_text(parent, height=8):

    return tk.Text(
        parent,
        height=height,
        font=("Segoe UI", 10),
        fg=color("text"),
        bg=color("entry"),
        insertbackground=color("cyan"),
        selectbackground=color("purple"),
        relief="flat",
        bd=0,
        wrap="word"
    )


def title_label(parent, text):

    tk.Label(
        parent,
        text=text,
        font=("Segoe UI", 22, "bold"),
        fg=color("cyan"),
        bg=color("bg")
    ).pack(
        pady=(25, 5)
    )


def subtitle(parent, text):

    tk.Label(
        parent,
        text=text,
        font=("Segoe UI", 9),
        fg=color("muted"),
        bg=color("bg")
    ).pack(
        pady=(0, 20)
    )


def section(parent, title):

    frame = tk.Frame(
        parent,
        bg=color("panel"),
        highlightbackground=color("border"),
        highlightthickness=1
    )

    frame.pack(
        fill="x",
        padx=30,
        pady=10
    )

    tk.Label(
        frame,
        text=title,
        font=("Segoe UI", 13, "bold"),
        fg=color("purple"),
        bg=color("panel")
    ).pack(
        anchor="w",
        padx=18,
        pady=(15, 10)
    )

    return frame


# ============================================================
# SCROLL PAGE
# ============================================================

def create_scroll_page(parent):

    outer = tk.Frame(
        parent,
        bg=color("bg")
    )

    outer.pack(
        fill="both",
        expand=True
    )

    canvas = tk.Canvas(
        outer,
        bg=color("bg"),
        highlightthickness=0,
        bd=0
    )

    canvas.pack(
        side="left",
        fill="both",
        expand=True
    )

    scrollbar = tk.Scrollbar(
        outer,
        orient="vertical",
        command=canvas.yview,
        troughcolor=color("panel2"),
        activebackground=color("pink"),
        relief="flat",
        bd=0,
        width=12
    )

    scrollbar.pack(
        side="right",
        fill="y"
    )

    canvas.configure(
        yscrollcommand=scrollbar.set
    )

    inner = tk.Frame(
        canvas,
        bg=color("bg")
    )

    window_id = canvas.create_window(
        (0, 0),
        window=inner,
        anchor="nw"
    )

    def update_scrollregion(event=None):

        canvas.configure(
            scrollregion=canvas.bbox("all")
        )

    def resize_inner(event):

        canvas.itemconfigure(
            window_id,
            width=event.width
        )

        update_scrollregion()

    inner.bind(
        "<Configure>",
        update_scrollregion
    )

    canvas.bind(
        "<Configure>",
        resize_inner
    )

    def wheel(event):

        if hasattr(event, "delta"):

            canvas.yview_scroll(
                int(-event.delta / 120),
                "units"
            )

        elif event.num == 4:

            canvas.yview_scroll(
                -3,
                "units"
            )

        elif event.num == 5:

            canvas.yview_scroll(
                3,
                "units"
            )

        return "break"

    canvas.bind(
        "<MouseWheel>",
        wheel
    )

    canvas.bind(
        "<Button-4>",
        wheel
    )

    canvas.bind(
        "<Button-5>",
        wheel
    )

    return inner, canvas


# ============================================================
# NUMBER HELPERS
# ============================================================

def read_number(entry, default=1):

    try:

        value = float(
            entry.get().strip()
        )

        if value <= 0:
            return default

        return value

    except (ValueError, AttributeError):

        return default


def requested_cps():

    if cps_entry is None:
        return 1

    value = read_number(
        cps_entry,
        1
    )

    return max(
        0.1,
        min(
            value,
            MAX_CPS
        )
    )


# ============================================================
# AUTOMATION LOOPS
# ============================================================

def click_loop():

    global running

    while running and current_mode == "click":

        cps = requested_cps()

        mouse_controller.click(
            mouse.Button.left
        )

        time.sleep(
            max(
                0.001,
                1 / cps
            )
        )


def space_loop():

    global running

    while running and current_mode == "space":

        cps = requested_cps()

        keyboard_controller.press(
            keyboard.Key.space
        )

        keyboard_controller.release(
            keyboard.Key.space
        )

        time.sleep(
            max(
                0.001,
                1 / cps
            )
        )


def scroll_loop():

    global running

    while running and current_mode == "scroll":

        try:

            value = float(
                cps_entry.get().strip()
            )

        except (ValueError, AttributeError):

            value = 5

        if value == 0:
            value = 1

        direction = -1 if value > 0 else 1

        mouse_controller.scroll(
            0,
            direction
        )

        time.sleep(
            max(
                0.01,
                1 / abs(value)
            )
        )


def random_loop():

    global running

    while running and current_mode == "random":

        minimum = read_number(
            random_min_entry,
            8
        )

        maximum = read_number(
            random_max_entry,
            15
        )

        minimum = min(
            minimum,
            MAX_CPS
        )

        maximum = min(
            maximum,
            MAX_CPS
        )

        if maximum < minimum:
            maximum = minimum

        cps = random.uniform(
            minimum,
            maximum
        )

        mouse_controller.click(
            mouse.Button.left
        )

        time.sleep(
            max(
                0.001,
                1 / cps
            )
        )


def burst_loop():

    global running

    try:

        clicks = int(
            burst_clicks_entry.get()
        )

    except (ValueError, AttributeError):

        clicks = 20

    pause = read_number(
        burst_pause_entry,
        0.5
    )

    clicks = max(
        1,
        min(
            10000,
            clicks
        )
    )

    while running and current_mode == "burst":

        cps = requested_cps()

        for _ in range(clicks):

            if not running:
                break

            mouse_controller.click(
                mouse.Button.left
            )

            time.sleep(
                max(
                    0.001,
                    1 / cps
                )
            )

        if running:
            time.sleep(pause)


# ============================================================
# HOLD MODE
# ============================================================

def parse_key(text):

    value = text.strip().lower()

    if not value:
        return keyboard.Key.f8

    special = {
        "space": keyboard.Key.space,
        "enter": keyboard.Key.enter,
        "tab": keyboard.Key.tab,
        "shift": keyboard.Key.shift,
        "ctrl": keyboard.Key.ctrl,
        "alt": keyboard.Key.alt,
        "esc": keyboard.Key.esc
    }

    if value in special:
        return special[value]

    if value.startswith("f") and value[1:].isdigit():

        number = int(
            value[1:]
        )

        if 1 <= number <= 24:

            return getattr(
                keyboard.Key,
                f"f{number}"
            )

    if len(value) == 1:

        return keyboard.KeyCode.from_char(value)

    return keyboard.Key.f8


def hold_press(key):

    global hold_active

    if hold_key_entry is None:
        return

    if key == parse_key(
        hold_key_entry.get()
    ):

        hold_active = True


def hold_release(key):

    global hold_active

    if hold_key_entry is None:
        return

    if key == parse_key(
        hold_key_entry.get()
    ):

        hold_active = False


def hold_loop():

    global running

    while running and current_mode == "hold":

        if hold_active:

            cps = requested_cps()

            mouse_controller.click(
                mouse.Button.left
            )

            time.sleep(
                max(
                    0.001,
                    1 / cps
                )
            )

        else:

            time.sleep(0.01)


def start_hold_listener():

    global hold_listener

    stop_hold_listener()

    hold_listener = keyboard.Listener(
        on_press=hold_press,
        on_release=hold_release
    )

    hold_listener.daemon = True
    hold_listener.start()


def stop_hold_listener():

    global hold_listener
    global hold_active

    hold_active = False

    if hold_listener:

        try:
            hold_listener.stop()

        except Exception:
            pass

        hold_listener = None


# ============================================================
# JITTER
# ============================================================

def jitter_loop():

    global jitter_running

    while jitter_running:

        try:

            distance = float(
                jitter_distance_entry.get()
            )

        except (ValueError, AttributeError):

            distance = 10

        try:

            delay = float(
                jitter_delay_entry.get()
            )

        except (ValueError, AttributeError):

            delay = 0.1

        distance = max(
            1,
            distance
        )

        delay = max(
            0.01,
            delay
        )

        mouse_controller.move(
            random.uniform(
                -distance,
                distance
            ),
            random.uniform(
                -distance,
                distance
            )
        )

        time.sleep(delay)


def toggle_jitter():

    global jitter_running

    if jitter_running:

        jitter_running = False

        neon_popup(
            "Jitter",
            "Mouse Jitter gestopt.",
            "info"
        )

    else:

        jitter_running = True

        threading.Thread(
            target=jitter_loop,
            daemon=True
        ).start()

        neon_popup(
            "Jitter",
            "Mouse Jitter gestart.",
            "success"
        )


# ============================================================
# START / STOP
# ============================================================

def start_automation():

    global running

    if running:
        return

    delay = 0

    if start_delay_entry:

        try:

            delay = float(
                start_delay_entry.get()
            )

        except ValueError:

            delay = 0

        delay = max(
            0,
            min(
                60,
                delay
            )
        )

    running = True

    update_status()

    def worker():

        global running

        if delay > 0:

            end_time = time.time() + delay

            while running and time.time() < end_time:

                time.sleep(0.05)

        if not running:
            return

        if current_mode == "click":

            click_loop()

        elif current_mode == "space":

            space_loop()

        elif current_mode == "scroll":

            scroll_loop()

        elif current_mode == "random":

            random_loop()

        elif current_mode == "burst":

            burst_loop()

        elif current_mode == "hold":

            start_hold_listener()
            hold_loop()

    threading.Thread(
        target=worker,
        daemon=True
    ).start()


def stop_automation():

    global running

    running = False

    stop_hold_listener()

    update_status()


def toggle_automation():

    if running:

        stop_automation()

    else:

        start_automation()


def update_status():

    if not status_label:
        return

    try:

        if running:

            status_label.config(
                text="● ACTIVE",
                fg=color("green")
            )

            if start_button:

                start_button.config(
                    text="STOP  [ F9 ]",
                    fg=color("pink")
                )

        else:

            status_label.config(
                text="● OFFLINE",
                fg=color("red")
            )

            if start_button:

                start_button.config(
                    text="START  [ F9 ]",
                    fg=color("cyan")
                )

    except tk.TclError:
        pass


# ============================================================
# MODE
# ============================================================

def select_mode(mode):

    global current_mode

    if running:
        return

    current_mode = mode

    for name, button in mode_buttons.items():

        if name == mode:

            button.config(
                bg=color("cyan"),
                fg=color("bg")
            )

        else:

            button.config(
                bg=color("panel2"),
                fg=color("muted")
            )


def preset_cps(value):

    if value > MAX_CPS:

        value = MAX_CPS

    if cps_entry:

        cps_entry.delete(
            0,
            tk.END
        )

        cps_entry.insert(
            0,
            str(value)
        )


# ============================================================
# EMERGENCY STOP
# ============================================================

def emergency_stop():

    global running
    global jitter_running

    running = False
    jitter_running = False

    stop_hold_listener()

    try:
        root.after(
            0,
            update_status
        )

    except tk.TclError:
        pass


def emergency_key(key):

    try:

        if key == keyboard.Key.f10:

            emergency_stop()

    except Exception:
        pass


def start_emergency_listener():

    global emergency_listener

    if emergency_listener:
        return

    emergency_listener = keyboard.Listener(
        on_press=emergency_key
    )

    emergency_listener.daemon = True
    emergency_listener.start()


# ============================================================
# CUSTOM HOTKEY
# ============================================================

def hotkey_press(key):

    if not hotkey_entry:
        return

    try:

        configured = parse_key(
            hotkey_entry.get()
        )

        if key == configured:

            root.after(
                0,
                toggle_automation
            )

    except Exception:
        pass


def restart_hotkey_listener():

    global hotkey_listener

    if hotkey_listener:

        try:
            hotkey_listener.stop()

        except Exception:
            pass

        hotkey_listener = None

    if hotkey_entry is None:
        return

    hotkey_listener = keyboard.Listener(
        on_press=hotkey_press
    )

    hotkey_listener.daemon = True
    hotkey_listener.start()


# ============================================================
# SCHEDULER
# ============================================================

def scheduler_loop():

    global scheduler_running

    while scheduler_running:

        try:

            start_value = (
                scheduler_start_entry
                .get()
                .strip()
            )

            stop_value = (
                scheduler_stop_entry
                .get()
                .strip()
            )

            now = time.strftime("%H:%M")

            if start_value and now == start_value:

                if not running:

                    root.after(
                        0,
                        start_automation
                    )

                time.sleep(61)

            if stop_value and now == stop_value:

                if running:

                    root.after(
                        0,
                        stop_automation
                    )

                time.sleep(61)

        except Exception:
            pass

        time.sleep(1)


def toggle_scheduler():

    global scheduler_running
    global scheduler_thread

    if scheduler_running:

        scheduler_running = False

        neon_popup(
            "Scheduler",
            "Scheduler uitgeschakeld.",
            "info"
        )

        return

    scheduler_running = True

    scheduler_thread = threading.Thread(
        target=scheduler_loop,
        daemon=True
    )

    scheduler_thread.start()

    neon_popup(
        "Scheduler",
        "Scheduler ingeschakeld.",
        "success"
    )


# ============================================================
# AUTOMATION TAB
# ============================================================

def build_automation_tab():

    global status_label
    global start_button
    global cps_entry
    global start_delay_entry

    global random_min_entry
    global random_max_entry

    global burst_clicks_entry
    global burst_pause_entry

    global hold_key_entry

    global mode_buttons


    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "AUTOMATION CORE"
    )

    subtitle(
        page,
        "Alle automation-functies zijn beschikbaar."
    )

    # --------------------------------------------------------
    # MODE
    # --------------------------------------------------------

    frame = section(
        page,
        "AUTOMATION MODE"
    )

    modes = [
        ("Auto Clicker", "click"),
        ("Auto Space", "space"),
        ("Auto Scroll", "scroll"),
        ("Random CPS", "random"),
        ("Burst Mode", "burst"),
        ("Hold Mode", "hold")
    ]

    mode_buttons.clear()

    for text, mode in modes:

        button = neon_button(
            frame,
            text,
            lambda m=mode:
                select_mode(m),
            color("cyan")
        )

        button.pack(
            padx=15,
            pady=5
        )

        mode_buttons[mode] = button

    # --------------------------------------------------------
    # CPS
    # --------------------------------------------------------

    frame2 = section(
        page,
        "CPS"
    )

    tk.Label(
        frame2,
        text=f"Maximum: {MAX_CPS} CPS",
        font=("Segoe UI", 9),
        fg=color("muted"),
        bg=color("panel")
    ).pack(
        pady=5
    )

    cps_entry = make_entry(
        frame2,
        "10"
    )

    cps_entry.pack(
        pady=8,
        ipady=7
    )

    preset_frame = tk.Frame(
        frame2,
        bg=color("panel")
    )

    preset_frame.pack(
        pady=8
    )

    for value in [5, 10, 30, 100, 500, 1000]:

        neon_button(
            preset_frame,
            str(value),
            lambda v=value:
                preset_cps(v),
            color("blue"),
            7
        ).pack(
            side="left",
            padx=3
        )

    # --------------------------------------------------------
    # RANDOM SETTINGS
    # --------------------------------------------------------

    frame3 = section(
        page,
        "RANDOM CPS"

    )

    random_min_entry = make_entry(
        frame3,
        "8"
    )

    random_min_entry.pack(
        pady=5,
        ipady=6
    )

    tk.Label(
        frame3,
        text="Minimum CPS",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    random_max_entry = make_entry(
        frame3,
        "15"
    )

    random_max_entry.pack(
        pady=5,
        ipady=6
    )

    tk.Label(
        frame3,
        text="Maximum CPS",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    # --------------------------------------------------------
    # BURST
    # --------------------------------------------------------

    frame4 = section(
        page,
        "BURST MODE"
    )

    burst_clicks_entry = make_entry(
        frame4,
        "20"
    )

    burst_clicks_entry.pack(
        pady=5,
        ipady=6
    )

    tk.Label(
        frame4,
        text="Clicks per burst",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    burst_pause_entry = make_entry(
        frame4,
        "0.5"
    )

    burst_pause_entry.pack(
        pady=5,
        ipady=6
    )

    tk.Label(
        frame4,
        text="Pause in seconds",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    # --------------------------------------------------------
    # HOLD
    # --------------------------------------------------------

    frame5 = section(
        page,
        "HOLD MODE"
    )

    hold_key_entry = make_entry(
        frame5,
        "f8"
    )

    hold_key_entry.pack(
        pady=5,
        ipady=6
    )

    tk.Label(
        frame5,
        text="Hold key, bijvoorbeeld F8",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    # --------------------------------------------------------
    # START DELAY
    # --------------------------------------------------------

    frame6 = section(
        page,
        "START DELAY"
    )

    start_delay_entry = make_entry(
        frame6,
        "0"
    )

    start_delay_entry.pack(
        pady=8,
        ipady=7
    )

    tk.Label(
        frame6,
        text="Seconds before automation starts",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    # --------------------------------------------------------
    # START
    # --------------------------------------------------------

    status_label = tk.Label(
        page,
        text="● OFFLINE",
        font=("Segoe UI", 11, "bold"),
        fg=color("red"),
        bg=color("bg")
    )

    status_label.pack(
        pady=(20, 5)
    )

    start_button = neon_button(
        page,
        "START  [ F9 ]",
        toggle_automation,
        color("cyan"),
        28
    )

    start_button.pack(
        pady=8
    )

    neon_button(
        page,
        "EMERGENCY STOP  [ F10 ]",
        emergency_stop,
        color("red"),
        28
    ).pack(
        pady=8
    )

    select_mode("click")


# ============================================================
# JITTER TAB
# ============================================================

def build_jitter_tab():

    global jitter_distance_entry
    global jitter_delay_entry

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "◆ MOUSE JITTER"
    )

    subtitle(
        page,
        "Beweeg de muis automatisch met een instelbare afstand."
    )

    frame = section(
        page,
        "JITTER SETTINGS"
    )

    jitter_distance_entry = make_entry(
        frame,
        "10"
    )

    jitter_distance_entry.pack(
        pady=8,
        ipady=7
    )

    tk.Label(
        frame,
        text="Distance",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    jitter_delay_entry = make_entry(
        frame,
        "0.1"
    )

    jitter_delay_entry.pack(
        pady=8,
        ipady=7
    )

    tk.Label(
        frame,
        text="Delay in seconds",
        fg=color("muted"),
        bg=color("panel")
    ).pack()

    neon_button(
        frame,
        "START / STOP JITTER",
        toggle_jitter,
        color("pink"),
        25
    ).pack(
        pady=15
    )

    neon_button(
        page,
        "EMERGENCY STOP [ F10 ]",
        emergency_stop,
        color("red"),
        25
    ).pack(
        pady=15
    )


# ============================================================
# SCHEDULER TAB
# ============================================================

def build_scheduler_tab():

    global scheduler_start_entry
    global scheduler_stop_entry

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "◆ SCHEDULER"
    )

    subtitle(
        page,
        "Plan automatisch wanneer de automation start en stopt."
    )

    frame = section(
        page,
        "SCHEDULE"
    )

    tk.Label(
        frame,
        text="Start time (HH:MM)",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 10)
    ).pack(
        pady=(10, 4)
    )

    scheduler_start_entry = make_entry(
        frame,
        "12:00"
    )

    scheduler_start_entry.pack(
        pady=5,
        ipady=7
    )

    tk.Label(
        frame,
        text="Stop time (HH:MM)",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 10)
    ).pack(
        pady=(12, 4)
    )

    scheduler_stop_entry = make_entry(
        frame,
        "18:00"
    )

    scheduler_stop_entry.pack(
        pady=5,
        ipady=7
    )

    neon_button(
        frame,
        "ENABLE / DISABLE SCHEDULER",
        toggle_scheduler,
        color("purple"),
        28
    ).pack(
        pady=20
    )

    tk.Label(
        page,
        text="Gebruik 24-uursnotatie, bijvoorbeeld 09:30 of 21:45.",
        fg=color("muted"),
        bg=color("bg"),
        font=("Segoe UI", 9)
    ).pack(
        pady=15
    )


# ============================================================
# HOTKEY TAB
# ============================================================

def build_hotkey_tab():

    global hotkey_entry

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "◆ HOTKEYS"
    )

    subtitle(
        page,
        "Stel een toetsenbordtoets in om automation te starten of stoppen."
    )

    frame = section(
        page,
        "CUSTOM HOTKEY"
    )

    tk.Label(
        frame,
        text="Automation toggle key",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 10)
    ).pack(
        pady=(10, 5)
    )

    hotkey_entry = make_entry(
        frame,
        "f9"
    )

    hotkey_entry.pack(
        pady=5,
        ipady=7
    )

    neon_button(
        frame,
        "APPLY HOTKEY",
        restart_hotkey_listener,
        color("cyan"),
        25
    ).pack(
        pady=15
    )

    tk.Label(
        frame,
        text="Voorbeeld: f9, f8, space, enter, tab",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 9)
    ).pack(
        pady=(0, 15)
    )

    tk.Label(
        page,
        text="F10 blijft altijd beschikbaar als emergency stop.",
        fg=color("red"),
        bg=color("bg"),
        font=("Segoe UI", 9, "bold")
    ).pack(
        pady=15
    )


# ============================================================
# ABOUT TAB
# ============================================================

def build_about_tab():

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "NEXUS AUTOMATION"
    )

    subtitle(
        page,
        "Automation control interface"
    )

    frame = section(
        page,
        "SYSTEM"
    )

    information = (
        "NEXUS AUTOMATION\n\n"
        "Version: 1.0\n"
        "Engine: Python + Tkinter\n"
        "Input: pynput\n\n"
        "CONTROLS\n\n"
        "F9  - Start / Stop automation\n"
        "F10 - Emergency Stop\n\n"
        "MODES\n\n"
        "Auto Clicker\n"
        "Auto Space\n"
        "Auto Scroll\n"
        "Random CPS\n"
        "Burst Mode\n"
        "Hold Mode"
    )

    tk.Label(
        frame,
        text=information,
        font=("Segoe UI", 10),
        fg=color("text"),
        bg=color("panel"),
        justify="left"
    ).pack(
        anchor="w",
        padx=25,
        pady=25
    )


# ============================================================
# TAB NAVIGATION
# ============================================================

def clear_content():

    global current_tab

    for widget in content_container.winfo_children():
        widget.destroy()

    current_tab = None


def set_tab(tab_name):

    global current_tab

    if current_tab == tab_name:
        return

    clear_content()

    current_tab = tab_name

    if tab_name == "automation":
        build_automation_tab()

    elif tab_name == "jitter":
        build_jitter_tab()

    elif tab_name == "scheduler":
        build_scheduler_tab()

    elif tab_name == "hotkeys":
        build_hotkey_tab()

    elif tab_name == "about":
        build_about_tab()

    update_tab_buttons()


def update_tab_buttons():

    for name, button in tab_buttons.items():

        if name == current_tab:

            button.config(
                fg=color("cyan"),
                bg=color("panel2")
            )

        else:

            button.config(
                fg=color("muted"),
                bg=color("panel")
            )


# ============================================================
# HEADER
# ============================================================

def build_header(parent):

    header = tk.Frame(
        parent,
        bg=color("panel"),
        height=70
    )

    header.pack(
        fill="x"
    )

    header.pack_propagate(False)

    tk.Label(
        header,
        text="NEXUS",
        font=("Segoe UI", 18, "bold"),
        fg=color("cyan"),
        bg=color("panel")
    ).pack(
        side="left",
        padx=(25, 4)
    )

    tk.Label(
        header,
        text="AUTOMATION",
        font=("Segoe UI", 18, "bold"),
        fg=color("purple"),
        bg=color("panel")
    ).pack(
        side="left"
    )

    tk.Label(
        header,
        text="● SYSTEM READY",
        font=("Segoe UI", 9, "bold"),
        fg=color("green"),
        bg=color("panel")
    ).pack(
        side="right",
        padx=25
    )


# ============================================================
# TAB BAR
# ============================================================

def build_tab_bar(parent):

    global tab_bar
    global tab_indicator
    global tab_buttons

    tab_bar = tk.Frame(
        parent,
        bg=color("panel")
    )

    tab_bar.pack(
        fill="x"
    )

    tabs = [
        ("AUTOMATION", "automation"),
        ("JITTER", "jitter"),
        ("SCHEDULER", "scheduler"),
        ("HOTKEYS", "hotkeys"),
        ("ABOUT", "about")
    ]

    tab_buttons.clear()

    for text, name in tabs:

        button = tk.Button(
            tab_bar,
            text=text,
            font=("Segoe UI", 9, "bold"),
            fg=color("muted"),
            bg=color("panel"),
            activeforeground=color("cyan"),
            activebackground=color("panel2"),
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=18,
            pady=12,
            command=lambda n=name: set_tab(n)
        )

        button.pack(
            side="left"
        )

        tab_buttons[name] = button

    tab_indicator = tk.Frame(
        tab_bar,
        bg=color("cyan"),
        height=2
    )

    tab_indicator.pack(
        fill="x",
        side="bottom"
    )


# ============================================================
# FOOTER
# ============================================================

def build_footer(parent):

    footer = tk.Frame(
        parent,
        bg=color("panel")
    )

    footer.pack(
        fill="x",
        side="bottom"
    )

    tk.Label(
        footer,
        text="NEXUS AUTOMATION",
        font=("Segoe UI", 8),
        fg=color("muted"),
        bg=color("panel")
    ).pack(
        side="left",
        padx=15,
        pady=8
    )

    tk.Label(
        footer,
        text="F10 = EMERGENCY STOP",
        font=("Segoe UI", 8, "bold"),
        fg=color("red"),
        bg=color("panel")
    ).pack(
        side="right",
        padx=15,
        pady=8
    )


# ============================================================
# MAIN GUI
# ============================================================

def build_gui():

    global content_container

    build_header(root)

    build_tab_bar(root)

    content_container = tk.Frame(
        root,
        bg=color("bg")
    )

    content_container.pack(
        fill="both",
        expand=True
    )

    build_footer(root)

    set_tab("automation")


# ============================================================
# CLOSE
# ============================================================

def on_close():

    global running
    global jitter_running
    global scheduler_running

    running = False
    jitter_running = False
    scheduler_running = False

    stop_hold_listener()

    if emergency_listener:

        try:
            emergency_listener.stop()
        except Exception:
            pass

    if hotkey_listener:

        try:
            hotkey_listener.stop()
        except Exception:
            pass

    try:
        root.destroy()
    except Exception:
        pass


# ============================================================
# LISTENERS
# ============================================================

def setup_listeners():

    start_emergency_listener()
    restart_hotkey_listener()


# ============================================================
# START
# ============================================================

def main():

    build_gui()

    setup_listeners()

    update_status()

    root.protocol(
        "WM_DELETE_WINDOW",
        on_close
    )

    root.mainloop()


if __name__ == "__main__":
    main()



# ============================================================
# SCHEDULER TAB
# ============================================================

def build_scheduler_tab():

    global scheduler_start_entry
    global scheduler_stop_entry

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "◆ SCHEDULER"
    )

    subtitle(
        page,
        "Plan automatisch wanneer de automation start en stopt."
    )

    frame = section(
        page,
        "SCHEDULE"
    )

    tk.Label(
        frame,
        text="Start time (HH:MM)",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 10)
    ).pack(pady=(10, 4))

    scheduler_start_entry = make_entry(
        frame,
        "12:00"
    )

    scheduler_start_entry.pack(
        pady=5,
        ipady=7
    )

    tk.Label(
        frame,
        text="Stop time (HH:MM)",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 10)
    ).pack(pady=(12, 4))

    scheduler_stop_entry = make_entry(
        frame,
        "18:00"
    )

    scheduler_stop_entry.pack(
        pady=5,
        ipady=7
    )

    neon_button(
        frame,
        "ENABLE / DISABLE SCHEDULER",
        toggle_scheduler,
        color("purple"),
        28
    ).pack(
        pady=20
    )

    tk.Label(
        page,
        text="Gebruik 24-uursnotatie, bijvoorbeeld 09:30 of 21:45.",
        fg=color("muted"),
        bg=color("bg"),
        font=("Segoe UI", 9)
    ).pack(
        pady=15
    )


# ============================================================
# HOTKEY TAB
# ============================================================

def build_hotkey_tab():

    global hotkey_entry

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "◆ HOTKEYS"
    )

    subtitle(
        page,
        "Stel een toetsenbordtoets in om automation te starten of stoppen."
    )

    frame = section(
        page,
        "CUSTOM HOTKEY"
    )

    tk.Label(
        frame,
        text="Automation toggle key",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 10)
    ).pack(
        pady=(10, 5)
    )

    hotkey_entry = make_entry(
        frame,
        "f9"
    )

    hotkey_entry.pack(
        pady=5,
        ipady=7
    )

    neon_button(
        frame,
        "APPLY HOTKEY",
        restart_hotkey_listener,
        color("cyan"),
        25
    ).pack(
        pady=15
    )

    tk.Label(
        frame,
        text="Voorbeeld: f9, f8, space, enter, tab",
        fg=color("muted"),
        bg=color("panel"),
        font=("Segoe UI", 9)
    ).pack(
        pady=(0, 15)
    )

    tk.Label(
        page,
        text="F10 blijft altijd beschikbaar als emergency stop.",
        fg=color("red"),
        bg=color("bg"),
        font=("Segoe UI", 9, "bold")
    ).pack(
        pady=15
    )


# ============================================================
# ABOUT TAB
# ============================================================

def build_about_tab():

    page, canvas = create_scroll_page(
        content_container
    )

    title_label(
        page,
        "NEXUS AUTOMATION"
    )

    subtitle(
        page,
        "Automation control interface"
    )

    frame = section(
        page,
        "SYSTEM"
    )

    information = (
        "NEXUS AUTOMATION\n\n"
        "Version: 1.0\n"
        "Engine: Python + Tkinter\n"
        "Input: pynput\n\n"
        "CONTROLS\n\n"
        "F9  - Start / Stop automation\n"
        "F10 - Emergency Stop\n\n"
        "MODES\n\n"
        "Auto Clicker\n"
        "Auto Space\n"
        "Auto Scroll\n"
        "Random CPS\n"
        "Burst Mode\n"
        "Hold Mode\n\n"
        "Gebruik automation verantwoord."
    )

    tk.Label(
        frame,
        text=information,
        font=("Segoe UI", 10),
        fg=color("text"),
        bg=color("panel"),
        justify="left"
    ).pack(
        anchor="w",
        padx=25,
        pady=25
    )


# ============================================================
# TAB NAVIGATION
# ============================================================

def clear_content():

    global current_tab

    for widget in content_container.winfo_children():

        widget.destroy()

    current_tab = None


def set_tab(tab_name):

    global current_tab

    if current_tab == tab_name:
        return

    clear_content()

    current_tab = tab_name

    if tab_name == "automation":

        build_automation_tab()

    elif tab_name == "jitter":

        build_jitter_tab()

    elif tab_name == "scheduler":

        build_scheduler_tab()

    elif tab_name == "hotkeys":

        build_hotkey_tab()

    elif tab_name == "about":

        build_about_tab()

    update_tab_buttons()


def update_tab_buttons():

    for name, button in tab_buttons.items():

        if name == current_tab:

            button.config(
                fg=color("cyan"),
                bg=color("panel2")
            )

        else:

            button.config(
                fg=color("muted"),
                bg=color("panel")
            )


# ============================================================
# HEADER
# ============================================================

def build_header(parent):

    header = tk.Frame(
        parent,
        bg=color("panel"),
        height=70
    )

    header.pack(
        fill="x"
    )

    header.pack_propagate(False)

    tk.Label(
        header,
        text="NEXUS",
        font=("Segoe UI", 18, "bold"),
        fg=color("cyan"),
        bg=color("panel")
    ).pack(
        side="left",
        padx=(25, 4)
    )

    tk.Label(
        header,
        text="AUTOMATION",
        font=("Segoe UI", 18, "bold"),
        fg=color("purple"),
        bg=color("panel")
    ).pack(
        side="left"
    )

    tk.Label(
        header,
        text="● SYSTEM READY",
        font=("Segoe UI", 9, "bold"),
        fg=color("green"),
        bg=color("panel")
    ).pack(
        side="right",
        padx=25
    )


# ============================================================
# TAB BAR
# ============================================================

def build_tab_bar(parent):

    global tab_bar
    global tab_indicator
    global tab_buttons

    tab_bar = tk.Frame(
        parent,
        bg=color("panel")
    )

    tab_bar.pack(
        fill="x"
    )

    tabs = [
        ("AUTOMATION", "automation"),
        ("JITTER", "jitter"),
        ("SCHEDULER", "scheduler"),
        ("HOTKEYS", "hotkeys"),
        ("ABOUT", "about")
    ]

    tab_buttons.clear()

    for text, name in tabs:

        button = tk.Button(
            tab_bar,
            text=text,
            font=("Segoe UI", 9, "bold"),
            fg=color("muted"),
            bg=color("panel"),
            activeforeground=color("cyan"),
            activebackground=color("panel2"),
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=18,
            pady=12,
            command=lambda n=name: set_tab(n)
        )

        button.pack(
            side="left"
        )

        tab_buttons[name] = button

    tab_indicator = tk.Frame(
        tab_bar,
        bg=color("cyan"),
        height=2
    )

    tab_indicator.pack(
        fill="x",
        side="bottom"
    )


# ============================================================
# FOOTER
# ============================================================

def build_footer(parent):

    footer = tk.Frame(
        parent,
        bg=color("panel")
    )

    footer.pack(
        fill="x",
        side="bottom"
    )

    tk.Label(
        footer,
        text="NEXUS AUTOMATION",
        font=("Segoe UI", 8),
        fg=color("muted"),
        bg=color("panel")
    ).pack(
        side="left",
        padx=15,
        pady=8
    )

    tk.Label(
        footer,
        text="F10 = EMERGENCY STOP",
        font=("Segoe UI", 8, "bold"),
        fg=color("red"),
        bg=color("panel")
    ).pack(
        side="right",
        padx=15,
        pady=8
    )


# ============================================================
# MAIN GUI
# ============================================================

def build_gui():

    global content_container

    # Header
    build_header(root)

    # Tabs
    build_tab_bar(root)

    # Content
    content_container = tk.Frame(
        root,
        bg=color("bg")
    )

    content_container.pack(
        fill="both",
        expand=True
    )

    # Footer
    build_footer(root)

    # Default tab
    set_tab("automation")


# ============================================================
# WINDOW CLOSE
# ============================================================

def on_close():

    global running
    global jitter_running
    global scheduler_running

    running = False
    jitter_running = False
    scheduler_running = False

    stop_hold_listener()

    if emergency_listener:

        try:
            emergency_listener.stop()
        except Exception:
            pass

    if hotkey_listener:

        try:
            hotkey_listener.stop()
        except Exception:
            pass

    try:
        root.destroy()
    except Exception:
        pass


# ============================================================
# KEYBOARD LISTENERS
# ============================================================

def setup_listeners():

    start_emergency_listener()

    restart_hotkey_listener()


# ============================================================
# START APPLICATION
# ============================================================

def main():

    build_gui()

    setup_listeners()

    update_status()

    root.protocol(
        "WM_DELETE_WINDOW",
        on_close
    )

    root.mainloop()


if __name__ == "__main__":

    main()

